// src/app/Router.jsx

import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import AdminLayout from '../../shared/layout/AdminLayout';
import ProductListPage from '../../features/product/pages/ProductListPage';

const router = createBrowserRouter([
  {
    path: '/admin',
    element: <AdminLayout />,          // ← sidebar lives here
    children: [
      { index: true,       element: <div>Dashboard</div> },
      { path: 'products',  element: <ProductListPage /> }, // ← products page
      { path: 'orders',    element: <div>Orders</div> },
    ],
  },
  { path: '*', element: <div>404</div> },
]);

export default function Router() {
  return <RouterProvider router={router} />;
}