// src/store/auth.store.js

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export const useAuthStore = create(
  persist(
    (set) => ({
      token: null,
      user: null,

      // ✅ ADD THIS
      setAuth: (token, user) =>
        set({
          token,
          user,
        }),

      // ✅ ADD THIS
      logout: () =>
        set({
          token: null,
          user: null,
        }),
    }),
    { name: "auth-storage" }
  )
);