// src/features/products/components/ProductDetailPanel.jsx

import { useState } from 'react';
import './ProductDetailPanel.css';

export default function ProductDetailPanel({ product, onClose }) {
  const [qty, setQty] = useState(1);

  const discount = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  );

  return (
    <aside className="pdp">

      {/* close */}
      <button className="pdp-close" onClick={onClose}>
        <CloseIcon />
      </button>

      {/* image carousel (single image for now) */}
      <div className="pdp-img-wrap">
        <img src={product.image} alt={product.name} className="pdp-img" />
        <button className="pdp-fav">
          <HeartIcon />
        </button>
        <div className="pdp-dots">
          <span className="pdp-dot" />
          <span className="pdp-dot pdp-dot--active" />
          <span className="pdp-dot" />
        </div>
      </div>

      {/* name + stock */}
      <div className="pdp-header">
        <div>
          <h2 className="pdp-name">{product.name}</h2>
          <p className="pdp-stock">{product.stock} in stock</p>
        </div>
        {discount > 0 && (
          <span className="pdp-badge">-{discount}%</span>
        )}
      </div>

      {/* price + qty */}
      <div className="pdp-price-row">
        <div className="pdp-prices">
          <span className="pdp-price">${product.price.toFixed(2)}</span>
          <span className="pdp-original">${product.originalPrice.toFixed(2)}</span>
        </div>
        <div className="pdp-qty">
          <button
            className="pdp-qty-btn"
            onClick={() => setQty((q) => Math.max(1, q - 1))}
          >−</button>
          <span className="pdp-qty-val">{qty}</span>
          <button
            className="pdp-qty-btn pdp-qty-btn--plus"
            onClick={() => setQty((q) => q + 1)}
          >+</button>
        </div>
      </div>

      <hr className="pdp-divider" />

      {/* description */}
      <div className="pdp-section">
        <h3 className="pdp-section-title">Description</h3>
        <p className="pdp-desc">
          A fresh {product.name.toLowerCase()} sourced directly from trusted local farms.
          Rich in vitamins and natural goodness, perfect for everyday healthy eating.
          Available in limited quantities — order before stock runs out.
        </p>
      </div>

      {/* contact */}
      <div className="pdp-section">
        <h3 className="pdp-section-title">Contact</h3>
        <div className="pdp-contact">
          <div className="pdp-contact-item">
            <span className="pdp-contact-icon pdp-contact-icon--green">
              <PhoneIcon />
            </span>
            <span>+123 456 7890</span>
          </div>
          <div className="pdp-contact-item">
            <span className="pdp-contact-icon pdp-contact-icon--green">
              <MailIcon />
            </span>
            <span>info@grocerygo.com</span>
          </div>
        </div>
      </div>

      {/* add to cart */}
      <button
        className="pdp-cart-btn"
        disabled={!product.inStock}
      >
        <CartIcon />
        {product.inStock ? 'Add to Cart' : 'Out of Stock'}
      </button>

    </aside>
  );
}

/* ── icons ── */
function CloseIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
      <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
    </svg>
  );
}
function HeartIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 000-7.78z"/>
    </svg>
  );
}
function PhoneIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.8 19.79 19.79 0 01.22 1.18 2 2 0 012.18 0h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 7.91a16 16 0 006.22 6.22l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/>
    </svg>
  );
}
function MailIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
      <polyline points="22,6 12,13 2,6"/>
    </svg>
  );
}
function CartIcon() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
      <path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6"/>
    </svg>
  );
}