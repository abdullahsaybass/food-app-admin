// src/features/products/pages/ProductListPage.jsx

import { useState, useMemo } from 'react';
import ProductCard from '../components/ProductCard';
import ProductDetailPanel from '../components/ProductDetailPanel';
import './ProductListPage.css';

// ── mock data (swap with useProducts() hook + real API later) ──
const MOCK_PRODUCTS = [
  { _id: 'p1', name: 'Pineapple',  category: 'Fruits',  price: 8.10,  originalPrice: 9.80,  stock: 290, image: 'https://images.unsplash.com/photo-1550258987-190a2d41a8ba?w=300&q=80', inStock: true  },
  { _id: 'p2', name: 'Apple',      category: 'Fruits',  price: 7.90,  originalPrice: 9.20,  stock: 120, image: 'https://images.unsplash.com/photo-1567306226416-28f0efdc88ce?w=300&q=80', inStock: true  },
  { _id: 'p3', name: 'Banana',     category: 'Fruits',  price: 5.10,  originalPrice: 9.20,  stock: 145, image: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=300&q=80', inStock: true  },
  { _id: 'p4', name: 'Cherry',     category: 'Fruits',  price: 4.10,  originalPrice: 9.20,  stock: 220, image: 'https://images.unsplash.com/photo-1528821154924-2df8a9a5f7af?w=300&q=80', inStock: true  },
  { _id: 'p5', name: 'Burger',     category: 'Burger',  price: 12.00, originalPrice: 15.00, stock: 50,  image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=300&q=80', inStock: true  },
  { _id: 'p6', name: 'Smoothie',   category: 'Drinks',  price: 6.50,  originalPrice: 8.00,  stock: 0,   image: 'https://images.unsplash.com/photo-1505252585461-04db1eb84625?w=300&q=80', inStock: false },
  { _id: 'p7', name: 'Sushi Roll', category: 'Sushi',   price: 14.90, originalPrice: 18.00, stock: 80,  image: 'https://images.unsplash.com/photo-1607301405345-4c60c42c5a3e?w=300&q=80', inStock: true  },
  { _id: 'p8', name: 'Pop Corn',   category: 'Snacks',  price: 3.50,  originalPrice: 4.00,  stock: 310, image: 'https://images.unsplash.com/photo-1585647347483-22b66260dfff?w=300&q=80', inStock: true  },
  { _id: 'p9', name: 'Pizza',      category: 'Pizza',   price: 18.00, originalPrice: 22.00, stock: 60,  image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=300&q=80', inStock: true  },
];

const CATEGORIES = ['All', 'Fruits', 'Burger', 'Drinks', 'Sushi', 'Snacks', 'Pizza'];

export default function ProductListPage() {
  const [search, setSearch]       = useState('');
  const [category, setCategory]   = useState('All');
  const [selected, setSelected]   = useState(null);

  const filtered = useMemo(() => {
    return MOCK_PRODUCTS.filter((p) => {
      const matchCat    = category === 'All' || p.category === category;
      const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
      return matchCat && matchSearch;
    });
  }, [search, category]);

  return (
    <div className="plp-wrap">

      {/* ── top bar ── */}
      <div className="plp-topbar">
        <div className="plp-topbar-left">
          <h1 className="plp-title">Products</h1>
          <span className="plp-count">{filtered.length} items</span>
        </div>
        <div className="plp-topbar-right">
          <div className="plp-search">
            <SearchIcon />
            <input
              placeholder="Search Grocery here..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="plp-date">12 Jan 2024  9:00 AM</div>
        </div>
      </div>

      {/* ── category tabs ── */}
      <div className="plp-cats">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            className={`plp-cat-btn ${category === cat ? 'plp-cat-btn--active' : ''}`}
            onClick={() => setCategory(cat)}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* ── body: grid + detail panel ── */}
      <div className="plp-body">
        <div className="plp-grid">
          {filtered.length === 0 && (
            <div className="plp-empty">No products found</div>
          )}
          {filtered.map((product) => (
            <ProductCard
              key={product._id}
              product={product}
              isSelected={selected?._id === product._id}
              onClick={() => setSelected(product)}
            />
          ))}
        </div>

        {selected && (
          <ProductDetailPanel
            product={selected}
            onClose={() => setSelected(null)}
          />
        )}
      </div>

    </div>
  );
}

function SearchIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth="2">
      <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
    </svg>
  );
}