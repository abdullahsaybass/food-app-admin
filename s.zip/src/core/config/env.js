// src/core/config/env.js

export const ENV = {
  API_URL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
};